<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php

		
		$db=mysqli_connect("localhost:3306","user","12345","dbnew");
		if(!$db){
			echo "error : data base not present ";
		}
		else{
			$na=$_POST["uname"];
			$pa=$_POST["psw"];
			$flag=$db->query("SELECT * FROM tbnew WHERE username='$na'");
			if(mysqli_num_rows($flag)>=1){
				$res=mysqli_fetch_object($flag);
				$p=$res->password;
				if($pa===$p){
					echo "<h1 style='color:red;margin-left:50px'> You have successfully logged in</br></h1>";
				echo "<a href='homepage (2).html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
					session_start();
					$_SESSION['uk']=$na;
				}
				else{

					echo "<h2 style='color:green;padding:100px;text-align:center'>your password is incorrect </br> </h2>";
					"<h2 style='color:green;padding:100px'>your password is incorrect</h2>";
					echo "<a href='forgotpage.html'><button style='background:blue;padding:8px;color:white;margin-left:300px;width:300px'>? Forgot Password </button></a>";

					echo "<a href='index.html'><button style='background:blue;padding:8px;color:white;margin-left:200px;width:300px'>Go back</button></a>";
				}
			}
			else{
				echo "<h2 style='color:green;padding:100px;text-align:center'>your account is not present go to signup page </h2>";
				echo "<a href='signup.php'><button style='background:blue;padding:8px;color:white;margin-left:525px;width:300px'> Sign up </button></a>";
			}
		}
	?>
</body>
</html>