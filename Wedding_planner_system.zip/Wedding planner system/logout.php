<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		session_start();
		unset($_SESSION['uk']);
		unset($_SESSION['total']);

	?>
	<h1 style="color:red;text-align:center">Go to HOMEPAGE</h1>
	<a href="homepage (2).html">Go to homepage</a>
</body>
</html>