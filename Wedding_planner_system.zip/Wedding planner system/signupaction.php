<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		// extract($_POST);
		// echo "$name";
		$na=$_POST["name"];
		$em=$_POST["em"];
		$pa=$_POST["pword"];
		$db=mysqli_connect("localhost:3306","user","12345","dbnew");
		if(!$db){
			echo "error";
		}
		// $stmt="SELECT * FROM tbnew WHERE username='".$name."'and email='".$em."'and password='".$pword."';";
		// echo "</br>.$stmt";
		$exist=$db->query("SELECT * FROM tbnew WHERE username='$na'");
		if(mysqli_num_rows($exist)>=1){
			echo "<h1 style='color:red;margin-left:50px'>User Exist</br></h1>";
				echo "<a href='index.html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Login</button></a>";
		}
		else{
		$new="INSERT INTO tbnew (username,email,password) VALUES('$na','$em','$pa')";

		if($db->query($new)===TRUE){
			echo "<h1 style='color:red;margin-left:50px'>Successfully Created</br></h1>";
				echo "<a href='homepage (2).html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
		}
		else{
			echo "errror";
		}
			}
		// $res=mysqli_query($db,$stmt);
		// print_r($res);



	?>
</body>
</html>