<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$na=$_POST['uname'];
		$pa=$_POST['psw'];
		$db=mysqli_connect("localhost:3306","user","12345","dbnew");
		if(!$db){
			echo "error";
		}
		else{
			$s=$db->query("SELECT * FROM tbnew WHERE username='$na'");
			if(mysqli_num_rows($s)>=1){
				$r=mysqli_fetch_object($s);
				$n=$r->username;
				$e=$r->email;
				$r=$db->query("UPDATE tbnew SET password='$pa' WHERE username='$na'");
				// echo $r->password;
				echo "<h1 style='color:pink;margin-left:50px'>successfully changed</br></h1>";
				echo "<a href='homepage (2).html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:300px;margin-top:100px'> Go to your home page</button></a>";
			}
			else{
				echo "<h1 style='color:red;text-align:center;padding:20px;margin-top:100px'>Invalid username <br>";
					echo "<a href='forgotpage.html'><button style='background:green;padding:8px;color:white;margin-left:50px;width:100px;margin-top:100px'> Go back</button></a>";
			}


		}
	?>
</body>
</html>