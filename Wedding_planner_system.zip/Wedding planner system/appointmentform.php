<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
<?php session_start();?>
<body>
	<?php
		$db=mysqli_connect("localhost:3306","user","12345","dbnew");
		if(!$db){
			echo "error : data base not present ";
		}
		else{
      if(isset($_SESSION['uk']) && isset($_SESSION['total'])){
			$na=$_SESSION['uk'];
			$s=$db->query("SELECT * FROM tbnew WHERE username='$na'");
			$k=(mysqli_fetch_object($s));
			$em=$k->email;
      $k1=$_SESSION['total'];
			}
		;
    }
	?>
  <?php
  if(isset($_SESSION['uk']))
  {
    echo "
	<form>
			<table id='customers'>
  <tr>
    <th></th>
    <th>User Details</th>

  </tr>
  <tr>
    <td>Name</td>
    <td>$na</td>

  </tr>
  <tr>
    <td>Email iD</td>
    <td>$em</td>

  </tr>
  <td>Total Amount</td>
    <td>$k1</td>
    
  </tr>
  <tr>
  	 <td>Date of Meeting</td>
    <td>22-11-2018</td>
  </tr>
 	</form>
  <p style='color:red;text-align:center'>Advance amount of 50000 to be paid in the next 46 hours </br> Half of the amount to br paid within next fortnight and rest half after the wedding </br><h2 style='color:purple;text-align:center'><span style='color:red'>*</span>Any Extra services needed will be charged extra</h2></p>
  ";
  }
    ?>
GO back to <a href="homepage (2).html">Homepage</a>
<span style="text-align:right;margin-left:1150px"><a href="logout.php">logout</a></span>
</body>
</html>