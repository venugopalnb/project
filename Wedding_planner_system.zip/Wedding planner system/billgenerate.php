<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<style type="text/css">
	#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
<body>
	<?php
		session_start();
		if(!isset($_SESSION['uk'])){
			echo "<h2 style='color:blue;text-align:center;margin-top:50px;padding:100px'>OOPS !!!!,you have to login <h2></br>";
			echo "<a href='index.html'><button style='background:blue;padding:8px;color:white;margin-left:525px;width:300px'>GO to login page</button></a>";
			unset($_SESSION['uk']);
		}
		else{
		$t=$_POST['th_choice'];
		// $s=$_POST['sang_choice'];
		// $so=$_POST['so_choice'];

		$con=mysqli_connect("localhost:3306","user","12345","dbnew");
		// $k=$_SESSION['uk'];
		$k=$_SESSION['uk'];
		if(!$con){
			echo "<p style='color:blue;font-family:Arial'>OOops ....something is wrong</p>";
		}
		else{
			$o=explode(' ',$t);
			$me=$o[1];
			$ch=$o[0];

			$o1=30000;
			$o2=30000;
			// $me1=explode("(",$me);
			// $me2=explode(")",$me1);
			echo "<h1 style='color:blue;text-align:center'>Dear,   $k</h1>'.' ";
			$ime=(int)$o[3];
			$am=$ime+$o1+$o2;

			$_SESSION['total']=$am;
		}

	}

	?>
	<?php
	if(isset($_SESSION['uk']))
		echo"
	<table id='customers'>
  <tr>
    <th>SERVICES</th>
    <th>Amount in RS</th>

  </tr>
  <tr>
    <td>$o[0] $o[1] $o[2]</td>
    <td>$o[3]</td>

  </tr>
  <tr>
    <td>Sangeeth  Choreography</td>
    <td>$o1</td>

  </tr>
  <td>Management and Hospitality</td>
    <td>$o2</td>
    
  </tr>
  <tr style='color:red'>
  	 <td>Total Amount </td>
    <td>$am</td>
  </tr>
 


</table>
<p style='text-align:center;color:green'>This is the total bill as per your choicesw and you can come and talk to us regarding other services</p>	
<a href='appointmentform.php'>create Appointment</a>
"?>
</body>
</html>